package kodlama.io.springBoot2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
